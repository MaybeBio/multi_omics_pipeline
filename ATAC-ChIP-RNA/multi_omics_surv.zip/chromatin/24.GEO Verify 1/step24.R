
library(caret)
setwd("E:\\生信\\chromatin\\24_step24")
data<-read.table("Riskscore.txt",header=T,sep="\t",check.names = F)
set.seed(666)
td<-createDataPartition(y=data$status,p=0.7,list=F)
traind<-data[td,]
rownames(traind)=traind$id
mycoef=read.table("gene_coef.txt",header = T,sep="\t")
mycoef$coef
expcoef=function(x){crossprod(as.numeric(x),mycoef$coef)}
Riskscore=apply(traind[,4:ncol(traind)],1,expcoef)
Riskgroup=as.vector(ifelse(Riskscore>median(Riskscore),"High","Low"))
newdf2=cbind(traind,Riskscore=as.vector(Riskscore),Riskgroup)
write.table(newdf2,"Riskscoretest.txt",sep="\t",quote=F,row.names=F)
