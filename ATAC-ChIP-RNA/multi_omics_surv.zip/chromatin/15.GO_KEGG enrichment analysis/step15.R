
library(org.Hs.eg.db)
library(clusterProfiler)
library(enrichplot)
library(ggplot2)

setwd("E:\\生信\\chromatin\\15_step15") 
gene_symbol=read.table("diffgene.txt",sep="\t",check.names=F,header=T)
gene_name=as.vector(gene_symbol[,1])
id=as.data.frame(gene_name)
geneID <- mget(gene_name, org.Hs.egSYMBOL2EG, ifnotfound=NA)
geneID <- as.character(geneID)
data=cbind(gene_symbol,entrezID=geneID)
write.table(id,"id.txt",sep="\t",quote = F,row.names = F,col.names = F)
write.table(data,"name_id.txt",sep="\t",quote = F,row.names = F)

#GO
go <- enrichGO(gene=data$entrezID,
               OrgDb = org.Hs.eg.db, ont='ALL',pvalueCutoff = 0.05)#MF CC BP
write.csv(go,"go.csv",row.names =F)
pdf("GO1.pdf",12,10)
barplot(go, drop = T, showCategory =5,split="ONTOLOGY") + facet_grid(ONTOLOGY~., scale='free')#条目可以更改
dev.off()
pdf("GO2.pdf",10,8)
dotplot(go,showCategory = 5,split="ONTOLOGY")+ facet_grid(ONTOLOGY~., scale='free')
dev.off()

##KEGG
kegg <- enrichKEGG(gene = data$entrezID,organism ="human",pvalueCutoff = 0.05)
write.csv(kegg,"KEGG.csv",row.names =F)
pdf("kegg1.pdf",10,8)
barplot(kegg, showCategory =10)
dev.off()

pdf("kegg2.pdf",10,8)
dotplot(kegg,showCategory = 10)
dev.off()


