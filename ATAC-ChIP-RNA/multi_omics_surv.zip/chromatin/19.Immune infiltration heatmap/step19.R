
setwd("E:\\生信\\chromatin\\19_step19")
library(limma)
library(pheatmap)
tcga<-read.table("All_infiltration_estimation.csv",header = T,sep = ",",check.names = F)
tcga=as.matrix(tcga)
rownames(tcga)=tcga[,1]
GeneExp=tcga[,2:ncol(tcga)]
TCGA=matrix(as.numeric(as.matrix(GeneExp)),nrow=nrow(GeneExp),dimnames=list(rownames(GeneExp),colnames(GeneExp)))
nc=substr(rownames(TCGA),1,12)
rownames(TCGA)=nc
TCGA=avereps(TCGA)
tumor=cbind(id=row.names(TCGA),TCGA)
risk=read.table("Riskscore.txt",header = T,sep = "\t",check.names = F)
risk_mRNA=merge(risk,tumor,by="id")
rownames(risk_mRNA)=risk_mRNA$id
risk_mRNA=risk_mRNA[,-1]
myresult=data.frame()
mygroup=c("Riskscore")
for(i in colnames(risk_mRNA)[2:ncol(risk_mRNA)]){
    mytest=wilcox.test(as.numeric(risk_mRNA[,i]) ~ risk_mRNA[,"Riskscore"])
    p=mytest$p.value
  if(p<0.05){
    myresult=rbind(myresult,cbind(id=i, p))
    mygroup=c(mygroup, i)
  }
}
write.table(myresult,"myresult.txt" ,sep="\t", quote=F, row.names=F)

ht=risk_mRNA[,mygroup]

ht=ht[order(ht[,"Riskscore"]),]
cann=ht[,1,drop=F]
cann[,"Riskscore"]=factor(cann[,"Riskscore"], unique(cann[,"Riskscore"]))
ht=t(ht[,(2:ncol(ht))])


rann=sapply(strsplit(rownames(ht),"_"), '[', 2)
rann=as.data.frame(rann)
row.names(rann)=row.names(ht)
colnames(rann)=c("Methods")
rann[,"Methods"]=factor(rann[,"Methods"], unique(rann[,"Methods"]))
cgap=as.vector(cumsum(table(cann[,"Riskscore"])))
rgap=as.vector(cumsum(table(rann[,"Methods"])))

mycolor=rainbow(9)
mycolor=mycolor[1:length(unique(cann[,"Riskscore"]))]
Riskscore=mycolor
names(Riskscore)=levels(factor(cann[,"Riskscore"]))
colorslist=list(Riskscore=Riskscore)

ht=matrix(as.numeric(as.matrix(ht)),nrow=nrow(ht),
          dimnames=list(rownames(ht),colnames(ht)))

pdf("immheatmap.pdf", 10,8)
pheatmap(ht,
         annotation=cann,
         annotation_row=rann,
         annotation_colors = colorslist,
         color = colorRampPalette(c(rep("blue",5), "white", rep("red",5)))(100),
         cluster_cols =F,
         cluster_rows =F,
         gaps_row=rgap,
         gaps_col=cgap,
         scale="row",
         show_colnames=F,
         show_rownames=T,
         fontsize=6,
         fontsize_row=5,
         fontsize_col=6)
dev.off()

