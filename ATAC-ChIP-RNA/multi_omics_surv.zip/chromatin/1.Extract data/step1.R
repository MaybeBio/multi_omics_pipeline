setwd("E:\\生信\\chromatin\\1_step1")
chromatin=read.table("chromatin.txt",header = T,sep = "\t",check.names = F)
mrna=read.table("mRNA.txt",header = T,sep = "\t",check.names=F)
chromatin_gene=merge(chromatin,mrna,by="id")
write.table(chromatin_gene,"chromatin_mRNA.txt",quote = F,row.names = F,sep = "\t")


