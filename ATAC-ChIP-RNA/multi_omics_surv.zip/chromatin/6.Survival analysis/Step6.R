

library(survival)
library(survminer)
setwd("E:\\生信\\chromatin\\6_step6")      
mydata=read.table("Riskscore.txt", header=T, sep="\t", check.names=F)
mydiff=survdiff(Surv(survival_time, status) ~Riskgroup,data = mydata)
myfit <- survfit(Surv(survival_time, status) ~ Riskgroup, data = mydata)
p=1-pchisq(mydiff$chisq,df=1)
if(p<0.001){
  p="p<0.001"
	}else{
	  p=paste0("p=",sprintf("%.03f",p))
	}

pdf("survival_risk.pdf",onefile = FALSE,10,8)
ggsurvplot(myfit, 
		           data=mydata,
		           conf.int=T,
		           pval=p,
		           pval.size=6,
		           legend.title="Risk",
		           legend.labs=c("High risk", "Low risk"),
		           xlab="Time(years)",
		           break.time.by = 1,
		           palette=c("red", "blue"),
		           risk.table=TRUE,
		       	   risk.table.title="",
		           risk.table.col = "strata",
		           risk.table.height=.25)
dev.off()


#############################################################################
#######################################riskline##############################
myrisk=read.table("Riskscore.txt",sep="\t",
                  header=T,row.names=1,check.names=F)

head(myrisk)
myrisk=myrisk[order(myrisk$Riskscore),]    
mygroup=myrisk[,"Riskgroup"]
ll=length(mygroup[mygroup=="Low"])
hl=length(mygroup[mygroup=="High"])
lm=max(myrisk$Riskscore[mygroup=="Low"])
line=myrisk[,"Riskscore"]
line[line>10]=10
pdf("riskline.pdf",8,6)
plot(line, type="p", pch=16,
     xlab="Patients (increasing risk socre)", ylab="Risk score",
     col=c(rep("green",ll),rep("red",hl)) )
abline(h=lm,v=ll,lty=2)
dev.off()

pdf("riskpoint.pdf",8,6)
plot(myrisk$survival_time, pch=16,
     xlab="Patients (increasing risk socre)", ylab="Survival time (years)",
     col=ifelse(myrisk$status=="1","red","blue"))
legend("topright", c("Dead", "Alive"),pch=16,col=c("red","blue"),cex=1.2)
abline(v=ll,lty=2)
dev.off()
