
setwd("E:\\生信\\chromatin\\10_step10")
risk=read.table("Riskscore.txt",header = T,sep = "\t")
clinical=read.table("clinical.txt",header = T,sep = "\t")
riskcli=merge(risk,clinical,by="id")
write.table(riskcli,"riskcli.txt",quote = F,sep = "\t",row.names = F)

mykf=read.table("riskcli.txt",header=T,sep="\t",check.names=F)
head(mykf)
group1="Riskscore" 
group2="radiotherapy" # age sex chemotherapy radiotherapy stage     
kfresult=mykf[,c(group1,group2)]
mytable=table(kfresult)
chisq.test(mytable)
mytable


fisher.test(mytable)





