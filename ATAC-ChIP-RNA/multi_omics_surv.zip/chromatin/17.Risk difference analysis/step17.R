

setwd("E:\\生信\\chromatin\\17_step17")
library(limma)
tcga<-read.table("mRNA.txt",header = T,sep = "\t",check.names = F)
tcga=as.matrix(tcga)
rownames(tcga)=tcga[,1]
GeneExp=tcga[,2:ncol(tcga)]
TCGA=matrix(as.numeric(as.matrix(GeneExp)),nrow=nrow(GeneExp),dimnames=list(rownames(GeneExp),colnames(GeneExp)))
TCGA=avereps(TCGA)
TCGA=TCGA[rowMeans(TCGA)>0,]
st<- which(substr(colnames(TCGA),14,15) == '11')
tumor=TCGA[,-st]
tumor=as.data.frame(tumor)
nc=substr(colnames(tumor),1,12)
colnames(tumor)=nc
tumor=cbind(id=row.names(tumor),tumor)
#head(tumor)
tumor=t(tumor)

write.table(tumor,"tumor.txt",sep = "\t",quote = F,col.names = F)
mRNA=read.table("tumor.txt",header = T,sep = "\t",check.names =F)
risk=read.table("Riskscore.txt",header = T,sep = "\t",check.names = F)
risk_mRNA=merge(risk,mRNA,by="id")
risk_mRNA=risk_mRNA[order(risk_mRNA$Riskscore,decreasing = T),]
table(risk_mRNA$Riskscore)
risk_mRNA=t(risk_mRNA)
write.table(risk_mRNA,"risk_mRNA.txt",sep = "\t",quote = F,col.names = F)

####
m6Agene=read.table("risk_mRNA.txt",header = T,sep = "\t",check.names = F)
m6Agene=m6Agene[-1,]
m6Agene=as.matrix(m6Agene)
rownames(m6Agene)=m6Agene[,1]
geneE=m6Agene[,2:ncol(m6Agene)]
newgene=matrix(as.numeric(as.matrix(geneE)),nrow=nrow(geneE),
               dimnames=list(rownames(geneE),colnames(geneE)))
newdf=data.frame()

group1=264
group2=262

for(a in row.names(newgene)){
  mydata=rbind(geneexp=newgene[a,],mygroup=c(rep(1,group1),rep(2,group2)))
  mydata=as.matrix(t(mydata))
  wilcoxTest<-wilcox.test(geneexp ~ mygroup, data=mydata)
  group1mea=mean(newgene[a,1:group1])
  group2mea=mean(newgene[a,(group1+1):ncol(newgene)])
  logFC=log2(group2mea)-log2(group1mea)  
  p=wilcoxTest$p.value
  group1medi=median(newgene[a,1:group1])
  group2medi=median(newgene[a,(group1+1):ncol(newgene)])
  diffmedi=group2medi-group1medi
  newdf=rbind(newdf,
              cbind(gene=a,
                    group1mea=group1mea,
                    group2mea=group2mea,
                    logFC=logFC,
                    p=p))
  
  
}   

p=newdf[,"p"]
FDR=p.adjust(as.numeric(as.vector(p)),method="fdr")
newdf=cbind(newdf,FDR=FDR)
newdf=na.omit(newdf)
newdf2=which(newdf$group1mea==0 | newdf$group2mea==0)
newdf3=newdf[-newdf2,]
write.table(newdf3,"allgene.txt",sep="\t",row.names=F,quote=F)


