
library(glmnet)
library(survival)
setwd("E:\\生信\\chromatin\\5_step5")

mydata1<-read.table("timeexp.txt",header=T,sep="\t",row.names = 1,check.names = F,stringsAsFactors = F) 
mydata2=read.table("top20.txt",header=T,sep="\t",check.names=F)          
mydata1=mydata1[,c("survival_time","status",as.vector(mydata2[,1]))]
mydata1$survival_time=mydata1$survival_time/365

v1<-as.matrix(mydata1[,c(3:ncol(mydata1))])
v2 <- as.matrix(Surv(mydata1$survival_time,mydata1$status))
myfit <- glmnet(v1, v2, family = "cox")
pdf("lambda.pdf")
plot(myfit, xvar = "lambda", label = TRUE)
dev.off()
myfit2 <- cv.glmnet(v1, v2, family="cox",nfolds = 10)
pdf("min.pdf")
plot(myfit2)
abline(v=log(c(myfit2$lambda.min,myfit2$lambda.1se)),lty="dashed")
dev.off()

coe <- coef(myfit, s = myfit2$lambda.min)
act_index <- which(coe != 0)
act_coe <- coe[act_index]
lassogene=row.names(coe)[act_index]
gene_coef=cbind(id=lassogene,coef=act_coe)
write.table(gene_coef,"gene_coef.txt",sep="\t",quote=F,row.names=F)

mygeneEXP=mydata1[,lassogene]
expcoef=function(x){crossprod(as.numeric(x),act_coe)}
Riskscore=apply(mygeneEXP,1,expcoef)
Riskgroup=as.vector(ifelse(Riskscore>median(Riskscore),"High","Low"))
newdf2=cbind(mydata1[,c("survival_time","status",lassogene)],Riskscore=as.vector(Riskscore),Riskgroup)
newdf3=cbind(id=rownames(newdf2),newdf2)
write.table(newdf3,"Riskscore.txt",sep="\t",quote=F,row.names=F)


