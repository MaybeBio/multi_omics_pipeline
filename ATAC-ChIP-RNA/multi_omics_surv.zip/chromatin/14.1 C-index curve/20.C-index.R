
setwd("C:\\Users\\zxz96\\Desktop\\chromatin\\s1.C-index曲线")  



#引用包
library(dplyr)
library(survival)
library(rms)
library(pec)

my_risk_File="Riskscore.txt"     #风险文件
my_cli_File="clinical.txt"      #临床数据文件


#读取风险输入文件
risk=read.table(my_risk_File, header=T, sep="\t", check.names=F, row.names=1)
risk=risk[,c("futime", "fustat", "riskScore")]

#读取临床数据文件
cli=read.table(my_cli_File, header=T, sep="\t", check.names=F, row.names=1)

#合并数据
samSample=intersect(row.names(risk), row.names(cli))
risk1=risk[samSample,,drop=F]
cli=cli[samSample,,drop=F]
yifeng=cbind(risk1, cli)

#定义颜色
bioCol=rainbow(ncol(yifeng)-1, s=0.9, v=0.9)

#C-index值计算
riskScore=cph(Surv(futime,fustat)~riskScore, data=yifeng, surv=TRUE)
Age=cph(Surv(futime,fustat)~Age, data=yifeng, surv=TRUE)
Sex=cph(Surv(futime,fustat)~Sex, data=yifeng, surv=TRUE)
Chemotherapy=cph(Surv(futime,fustat)~Chemotherapy, data=yifeng, surv=TRUE)
Radiotherapy=cph(Surv(futime,fustat)~Radiotherapy, data=yifeng, surv=TRUE)
T=cph(Surv(futime,fustat)~T, data=yifeng, surv=TRUE)
N=cph(Surv(futime,fustat)~N, data=yifeng, surv=TRUE)
M=cph(Surv(futime,fustat)~M, data=yifeng, surv=TRUE)
yifeng_c_index  <- cindex(list("Risk score"=riskScore, 
                               "Age"=Age,
                               "Sex"=Sex,
                               "Chemotherapy"=Chemotherapy,
                               "Radiotherapy"=Radiotherapy,
                               "T"=T,
                               "N"=N,
                               "M"=M,), 
                          formula=Surv(futime,fustat)~ .,
                          data=yifeng,
                          eval.times=seq(0,10,1),
                          splitMethod="bootcv",
                          B=1000
)
#输出图形
pdf(file="C-index.pdf", width=5.5, height=5)
plot(yifeng_c_index, xlim=c(0,10), ylim=c(0.4,0.8), col=bioCol, legend.x=6, legend.y=0.82, legend.cex=1)
dev.off()
gc() #释放内存

