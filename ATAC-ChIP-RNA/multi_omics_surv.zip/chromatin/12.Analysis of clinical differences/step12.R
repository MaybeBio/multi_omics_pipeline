setwd("C:\\Users\\zxz96\\Desktop\\chromatin\\12.临床差异分析")
data1=read.table("Riskscore.txt",header = T,sep = "\t",check.names = F)
data2=read.table("clinical.txt",header = T,sep = "\t",check.names = F)
data3=merge(data1,data2,by="id")

for (a in colnames(data3[,3:ncol(data3)])){
scorename="Riskscore"
clinical=a
riskscore=data3
head(riskscore)
riskscore=riskscore[,c("id",clinical,scorename)]
colnames(riskscore)=c("id","clinical","score")

xlabel=vector()
tab1=table(riskscore[,"clinical"])
labn=length(tab1)
for(i in 1:labn ){
  xlabel=c(xlabel,names(tab1[i]))
}
mytest<-wilcox.test(score ~ clinical, data = riskscore)
p=mytest$p.value
if(p<0.001){
  p="p<0.001"
}else{
  p=paste0("p=",sprintf("%.03f",p))
}

mybox = boxplot(score ~ clinical, data = riskscore,outline = F, plot=F) 
ymin=min(mybox$stats)
ymax = max(mybox$stats/5+mybox$stats)
y1 = max(mybox$stats/10+mybox$stats)
y12 = max(mybox$stats/12+mybox$stats)
n = ncol(mybox$stats)

pdffile=paste(clinical,".pdf",sep="")
pdf(file=pdffile,8,8)
par(mar = c(4,7,3,3))
boxplot(score ~ clinical, data = riskscore,names=xlabel,xlab = "",main=clinical,
        ylab = paste(scorename),col=c("blue","red"),
        cex.main=1.6, cex.lab=1.4, cex.axis=1.3,ylim=c(ymin,ymax),outline = F)
segments(1,y1, n,y1);
segments(1,y1, 1,y12)
segments(n,y1, n,y12)
text((1+n)/2,y1,labels=p,cex=1.5,pos=3)
dev.off()
}
