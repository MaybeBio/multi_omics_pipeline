
library(org.Hs.eg.db)
library(clusterProfiler)
library(enrichplot)
library(ggplot2)
setwd("C:\\Users\\zxz96\\Desktop\\chromatin\\18.GSEA") 
data3=read.table("allgene.txt",sep="\t",check.names=F,header=T)
gene_name=as.vector(data3[,1])
geneID <- mget(gene_name, org.Hs.egSYMBOL2EG, ifnotfound=NA)
geneID <- as.character(geneID)
data=cbind(data3,entrezID=geneID)
write.table(data,"name_id.txt",sep="\t",quote = F,row.names = F)
mydata=data[,c("entrezID","logFC")]
mydata$logFC=sort(mydata$logFC,decreasing = T)
mygenelist=as.numeric(as.character(mydata$logFC))
names(mygenelist)=as.character(mydata$entrezID)

mygse <- gseKEGG(geneList     = mygenelist,
                 organism     = 'hsa',keyType = "kegg",
                 pvalueCutoff = 0.05,
                 pAdjustMethod = "none" )
gse_result <- as.data.frame(mygse)
write.table(gse_result,"gse_result.txt",quote = F,sep = "\t")

gseaplot2(mygse, geneSetID = rownames(mygse@result)[(order(mygse@result$enrichmentScore))][1:5])#可以更改




