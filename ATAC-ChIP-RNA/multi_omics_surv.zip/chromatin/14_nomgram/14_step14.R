
library(survival)
library(regplot)
library(rms)

setwd("E:\\桌面\\chromatin\\14_nomgram")

data1=read.table("cr_G.txt",header = T,sep = "\t",check.names =F,row.names = 1)
#nomogram
nomcox=coxph(Surv(survival_time, status) ~ . , data = data1)
regplot(nomcox,
        plots = c("bars", "boxes"),
        clickable=F,
        title=NULL,
        points=T,
        droplines=T,
        observation=data1[20,],#可以改病人编号
        rank="sd",
        failtime = c(1,3,5),
        prfail = F)

head(data1)
#校准曲线
pdf("calibration.pdf",10,8)
#1 year
mx1 <- cph(Surv(survival_time, status) ~age + sex + chemotherapy + radiotherapy + stage + Riskscore, x=T, y=T, surv=T, data=data1, time.inc=1)
cal1 <- calibrate(mx1, cmethod="KM", method="boot", u=1, m=(nrow(data1)/3), B=1000)
plot(cal1, xlim=c(0,1), ylim=c(0,1),
     xlab="Nomogram-predicted Overall survival (%)", ylab="Observed Overall survival (%)", lwd=1.5, col="green", sub=F)
#3 year
mx2 <- cph(Surv(survival_time, status) ~ age + sex + chemotherapy + radiotherapy + stage + Riskscore, x=T, y=T, surv=T, data=data1, time.inc=3)
cal2 <- calibrate(mx2, cmethod="KM", method="boot", u=3, m=(nrow(data1)/3), B=1000)
plot(cal2, xlim=c(0,1), ylim=c(0,1), xlab="", ylab="", lwd=1.5, col="blue", sub=F, add=T)

#5 year
mx3 <- cph(Surv(survival_time, status) ~age + sex + chemotherapy + radiotherapy + stage + Riskscore, x=T, y=T, surv=T, data=data1, time.inc=5)
cal3 <- calibrate(mx3, cmethod="KM", method="boot", u=5, m=(nrow(data1)/3), B=1000)
plot(cal3, xlim=c(0,1), ylim=c(0,1), xlab="", ylab="",  lwd=1.5, col="red", sub=F, add=T)
legend('bottomright', c('1-year', '3-year', '5-year'),
       col=c("green","blue","red"), lwd=1.5, bty = 'n')
dev.off()

library(rms)
library(foreign)
library(survival)
tcga<-read.table("cr.txt",header=T,sep="\t")
tcga$age<-factor(tcga$age,labels=c("<=65",">65"))
tcga$sex<-factor(tcga$sex,labels=c("FEMALE","MALE"))
tcga$radiotherapy<-factor(tcga$radiotherapy,labels=c("NO","YES"))
tcga$chemotherapy<-factor(tcga$chemotherapy,labels=c("NO","YES"))
tcga$stage<-factor(tcga$stage,labels=c("I_II","III_IV"))
tcga$Riskscore<-factor(tcga$Riskscore,labels=c("LOW","HIGH"))
ddist <- datadist(tcga)
options(datadist='ddist')
fmla1 <- as.formula(Surv(survival_time,status) ~ age + sex + radiotherapy + chemotherapy + stage + Riskscore)
cox2 <- cph(fmla1,data=tcga)
coxpe <- predict(cox2)#模型预测
c_index=1-rcorr.cens(coxpe,Surv(tcga$survival_time,tcga$status))
c_index
