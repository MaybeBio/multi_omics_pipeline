
library(pheatmap)
setwd("C:\\Users\\zxz96\\Desktop\\chromatin\\11.临床热图")
data1=read.table("Riskscore.txt",header = T,sep = "\t",check.names = F)
data2=read.table("clinical.txt",header = T,sep = "\t",check.names = F)
data3=merge(data1,data2,by="id")
write.table(data3,"clinicalheat.txt",sep = "\t",quote = F,row.names = F)


ht=read.table("geneheat.txt",sep="\t",header=T,
              row.names=1,check.names=F)   
ht=t(ht)

Group=read.table("clinicalheat.txt",sep="\t",
                 header=T,row.names=1,check.names=F)
Group=Group[order(Group$Riskscore),]
ht=ht[,row.names(Group)]

pdf("heatmap1.pdf",10,8)
pheatmap(ht, annotation=Group, 
         color = colorRampPalette(c("blue", "white", "red"))(50),
         cluster_cols =F,
         fontsize=7,
         fontsize_row=8,
         scale="row",
         show_colnames=F,
         fontsize_col=3)
dev.off()

