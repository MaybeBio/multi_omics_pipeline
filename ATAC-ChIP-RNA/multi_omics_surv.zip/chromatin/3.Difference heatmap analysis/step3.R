library(pheatmap)
setwd("E:\\����\\chromatin\\3.������ͼ����")
ht=read.table("diffgeneEXP.txt",header = T,sep = "\t",row.names = 1,check.names = F)
ht=log2(ht+1)
Group=c(rep("N",59),rep("T",539))   
names(Group)=colnames(ht)
Group=as.data.frame(Group)
ht=ht[1:50,]
pdf("heatmap.pdf",15,12)
pheatmap(ht, annotation=Group, 
         color = colorRampPalette(c("green4", "white", "red4"))(50),
         cluster_cols =F,show_colnames = F)
dev.off()

