


library(survival)
setwd("C:\\Users\\zxz96\\Desktop\\chromatin\\9.Cox回归分析")

data1=read.table("Riskscore.txt",header = T,sep = "\t",check.names = F)
data2<-read.table("clinical.txt",header=T,sep="\t",check.names = F)
data3=merge(data1,data2,by="id")
write.table(data3,"cr.txt",quote = F,sep = "\t",row.names = F)



#############################单因素Cox###########################################
ndata1=read.table("cr.txt",header = T,sep = "\t",check.names =F,row.names = 1)
coxf<-function(x){
  fmla1 <- as.formula(Surv(survival_time,status)~ndata1[,x])
  mycox <- coxph(fmla1,data=ndata1)
}

newdf=data.frame()
for(a in colnames(ndata1[,3:ncol(ndata1)])){
  mycox=coxf(a)
  coxResult = summary(mycox)
  newdf=rbind(newdf,
              cbind(id=a,
                    HR=coxResult$conf.int[,"exp(coef)"],
                    HR_95L=coxResult$conf.int[,"lower .95"],
                    HR_95U=coxResult$conf.int[,"upper .95"],
                    P=coxResult$coefficients[,"Pr(>|z|)"]
              ))
  
}
write.table(newdf,"result.txt",sep="\t",row.names=F,quote=F)

################################forest#############################################
HRdf1=read.table("result.txt",header=T,sep="\t",row.names=1,check.names=F)
idname <- rownames(HRdf1)
HR=sprintf("%.4f",HRdf1[,"HR"])
HR_95L=sprintf("%.4f",HRdf1[,"HR_95L"])
HR_95U=sprintf("%.4f",HRdf1[,"HR_95U"])
P=HRdf1[,"P"]
P=ifelse(P<0.001, "<0.001", sprintf("%.4f", P))

pdf("forest1.pdf",8,6)
snum <- nrow(HRdf1)
snum2 <- snum+1
layout(matrix(c(1,2),nc=2),width=c(3,2.5))
par(mar=c(4,2.5,2,1))
plot(1,xlim= c(0,3),ylim=c(1,snum2),type="n",axes=F,xlab="",ylab="")
text(0,snum:1,idname,adj=0,cex=0.8)
text(1.5-0.5*0.2,snum:1,P,adj=1,cex=0.8);text(1.5-0.5*0.2,snum+1,'pvalue',cex=0.8,font=2,adj=1)
text(3.1,snum:1, paste0(HR,"(",HR_95L,"-",HR_95U,")"),adj=1,cex=0.8);text(3.1,snum+1,'Hazard ratio',cex=0.8,font=2,adj=1)
par(mar=c(4,1,2,1),mgp=c(2,0.5,0))
xlim = c(0,max(as.numeric(HR_95L),as.numeric(HR_95U)))
plot(1,xlim=c(0,3),ylim=c(1,snum2),type="n",axes=F,ylab="",xaxs="i",xlab="Hazard ratio")
arrows(as.numeric(HR_95L),snum:1,as.numeric(HR_95U),
       snum:1,angle=90,code=3,length=0.05,col="skyblue",lwd=2.5)
abline(v=1,col="black",lty=2,lwd=2)
points(as.numeric(HR), snum:1, pch = 15, 
       col ="green"
       , cex=1.5)
axis(1)
dev.off()

#####################################


###########################################多因素Cox###################################
fmla2 <- as.formula(Surv(survival_time,status)~.)
mycox2 <- coxph(fmla2,data=ndata1)
coxResult2=summary(mycox2)
newdf2=cbind(
  HR=coxResult2$conf.int[,"exp(coef)"],
  HR_95L=coxResult2$conf.int[,"lower .95"],
  HR_95U=coxResult2$conf.int[,"upper .95"],
  P=coxResult2$coefficients[,"Pr(>|z|)"])
newdf2=cbind(id=row.names(newdf2),newdf2)

write.table(newdf2,"result2.txt",sep="\t",row.names=F,quote=F)

##################forest#############################################################
HRdf1=read.table("result2.txt",header=T,sep="\t",row.names=1,check.names=F)
idname <- rownames(HRdf1)
HR=sprintf("%.4f",HRdf1[,"HR"])
HR_95L=sprintf("%.4f",HRdf1[,"HR_95L"])
HR_95U=sprintf("%.4f",HRdf1[,"HR_95U"])
P=HRdf1[,"P"]
P=ifelse(P<0.001, "<0.001", sprintf("%.4f", P))

pdf("forest2.pdf",8,6)
snum <- nrow(HRdf1)
snum2 <- snum+1
layout(matrix(c(1,2),nc=2),width=c(3,2.5))
par(mar=c(4,2.5,2,1))
plot(1,xlim= c(0,3),ylim=c(1,snum2),type="n",axes=F,xlab="",ylab="")
text(0,snum:1,idname,adj=0,cex=0.8)
text(1.5-0.5*0.2,snum:1,P,adj=1,cex=0.8);text(1.5-0.5*0.2,snum+1,'pvalue',cex=0.8,font=2,adj=1)
text(3.1,snum:1, paste0(HR,"(",HR_95L,"-",HR_95U,")"),adj=1,cex=0.8);text(3.1,snum+1,'Hazard ratio',cex=0.8,font=2,adj=1)
par(mar=c(4,1,2,1),mgp=c(2,0.5,0))
xlim = c(0,max(as.numeric(HR_95L),as.numeric(HR_95U)))
plot(1,xlim=c(0,3),ylim=c(1,snum2),type="n",axes=F,ylab="",xaxs="i",xlab="Hazard ratio")
arrows(as.numeric(HR_95L),snum:1,as.numeric(HR_95U),
       snum:1,angle=90,code=3,length=0.05,col="skyblue",lwd=2.5)
abline(v=1,col="black",lty=2,lwd=2)
points(as.numeric(HR), snum:1, pch = 15, 
       col =  "red"
       , cex=1.5)
axis(1)
dev.off()

#####################################



