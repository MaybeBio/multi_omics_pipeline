
setwd("E:\\生信\\chromatin\\7_step7")
library(timeROC)
library(survival)
TCGA<-read.table("Riskscore.txt",header=T,sep="\t")
predict_1_year<- 1
predict_3_year<- 3
predict_5_year<- 5

ROC<-timeROC(T=TCGA$survival_time,delta=TCGA$status,
             marker=TCGA$Riskscore,cause=1,
             weighting="marginal",
             times=c(predict_1_year,predict_3_year,predict_5_year),ROC=T)

pdf("ROC.pdf")
plot(ROC,time=predict_1_year,title=F,lwd=3)
plot(ROC,time=predict_3_year,col="yellow",add=T,title=F,lwd=3)
plot(ROC,time=predict_5_year,col="blue",add=T,title=F,lwd=3)
legend("bottomright",
       c(paste("AUC of 1 year survival: ",round(ROC$AUC[1],3)),
         paste("AUC of 3 year survival: ",round(ROC$AUC[2],3)),
         paste("AUC of 5 year surviva",round(ROC$AUC[3],3))),col=c("red","yellow","blue"),lwd=3)#更改颜色
dev.off()
