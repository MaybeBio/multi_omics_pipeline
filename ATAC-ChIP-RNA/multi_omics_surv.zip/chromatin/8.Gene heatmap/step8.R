
library(pheatmap)       
setwd("E:\\生信\\chromatin\\8_step8")
riskdata=read.table("Riskscore.txt",header = T,sep = "\t",row.names = 1)
riskdata=riskdata[order(riskdata$Riskscore),]  
nriskdata=riskdata[c(3:(ncol(riskdata)-2))]
nriskdata=t(nriskdata)
nriskdata=log2(nriskdata+1)
mycolor=list()
mycolor2=c("green", "red")
names(mycolor2)=c("Low", "High")
mycolor[["Riskgroup"]]=mycolor2
ann=data.frame(Riskgroup=riskdata[,ncol(riskdata)])
rownames(ann)=rownames(riskdata)
pdf("heatmap.pdf",10,8)
pheatmap(nriskdata, 
         annotation=ann,
         annotation_colors = mycolor, 
         cluster_cols = F,
         cluster_rows = F,
         show_colnames = F,
         scale="row",
         color= colorRampPalette(c("green", "black", "red"))(50),
         fontsize_col=4,
         fontsize=8,
         fontsize_row=8)
dev.off()

