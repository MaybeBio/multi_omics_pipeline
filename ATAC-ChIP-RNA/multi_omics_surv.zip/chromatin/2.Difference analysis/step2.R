setwd("E:\\生信\\chromatin\\2_step2")
library(limma)
m6Agene=read.table("chromatin_mRNA.txt",header = T,sep = "\t",check.names = F)
m6Agene=as.matrix(m6Agene)
rownames(m6Agene)=m6Agene[,1]
geneE=m6Agene[,2:ncol(m6Agene)]
newgene=matrix(as.numeric(as.matrix(geneE)),nrow=nrow(geneE),
               dimnames=list(rownames(geneE),colnames(geneE)))
newgene=avereps(newgene)
newgene=newgene[rowMeans(newgene)>0,]
newdf=data.frame()
group1=59
group2=539
for(a in row.names(newgene)){
  mydata=rbind(geneexp=newgene[a,],mygroup=c(rep(1,group1),rep(2,group2)))
  mydata=as.matrix(t(mydata))
  wilcoxTest<-wilcox.test(geneexp ~ mygroup, data=mydata)
  group1mea=mean(newgene[a,1:group1])
  group2mea=mean(newgene[a,(group1+1):ncol(newgene)])
  logFC=log2(group2mea)-log2(group1mea)  
  p=wilcoxTest$p.value
  group1medi=median(newgene[a,1:group1])
  group2medi=median(newgene[a,(group1+1):ncol(newgene)])
  diffmedi=group2medi-group1medi
    newdf=rbind(newdf,
                cbind(gene=a,
                      group1mea=group1mea,
                      group2mea=group2mea,
                      logFC=logFC,
                      p=p))
  
  
}   
 
p=newdf[,"p"]
FDR=p.adjust(as.numeric(as.vector(p)),method="fdr")
newdf=cbind(newdf,FDR=FDR)
newdf=na.omit(newdf)
write.table(newdf,"allgene.txt",sep="\t",row.names=F,quote=F)

Diffgene=newdf[(abs(as.numeric(as.vector(newdf$logFC)))>1 & as.numeric(as.vector(newdf$FDR))<0.05),]#设置标准比较高，因为染色质基因太多了，800多基因
Diffgene=na.omit(Diffgene)
write.table(Diffgene,"diffgene.txt",sep="\t",row.names=F,quote=F)
ndf=newgene[Diffgene$gene,]
diffgeneEXP=cbind(id=row.names(ndf),ndf)
write.table(diffgeneEXP,"diffgeneEXP.txt",sep="\t",row.names=F,quote=F)


