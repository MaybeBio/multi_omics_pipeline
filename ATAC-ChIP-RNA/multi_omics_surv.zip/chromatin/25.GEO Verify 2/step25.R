

library(survival)
library(survminer)
library(timeROC)
library(pheatmap)
setwd("E:\\生信\\chromatin\\25_step25")      
mydata=read.table("Riskscore.txt", header=T, sep="\t", check.names=F)
mydiff=survdiff(Surv(survival_time, status) ~Riskgroup,data = mydata)
myfit <- survfit(Surv(survival_time, status) ~ Riskgroup, data = mydata)
p=1-pchisq(mydiff$chisq,df=1)
if(p<0.001){
  p="p<0.001"
}else{
  p=paste0("p=",sprintf("%.03f",p))
}

pdf("survival_risk.pdf",onefile = FALSE,10,8)
ggsurvplot(myfit, 
           data=mydata,
           conf.int=T,
           pval=p,
           pval.size=6,
           legend.title="Risk",
           legend.labs=c("High risk", "Low risk"),
           xlab="Time(years)",
           break.time.by = 1,
           palette=c("red", "blue"),
           risk.table=TRUE,
           risk.table.title="",
           risk.table.col = "strata",
           risk.table.height=.25)
dev.off()


#############################################################################
#######################################riskline##############################
myrisk=read.table("Riskscore.txt",sep="\t",
                  header=T,row.names=1,check.names=F)

head(myrisk)
myrisk=myrisk[order(myrisk$Riskscore),]    
mygroup=myrisk[,"Riskgroup"]
ll=length(mygroup[mygroup=="Low"])
hl=length(mygroup[mygroup=="High"])
lm=max(myrisk$Riskscore[mygroup=="Low"])
line=myrisk[,"Riskscore"]
line[line>10]=10
pdf("riskline.pdf",8,6)
plot(line, type="p", pch=16,
     xlab="Patients (increasing risk socre)", ylab="Risk score",
     col=c(rep("green",ll),rep("red",hl)) )
abline(h=lm,v=ll,lty=2)
dev.off()



pdf("riskpoint.pdf",8,6)
plot(myrisk$survival_time, pch=16,
     xlab="Patients (increasing risk socre)", ylab="Survival time (years)",
     col=ifelse(myrisk$status=="1","red","blue"))
legend("topright", c("Dead", "Alive"),pch=16,col=c("red","blue"),cex=1.2)
abline(v=ll,lty=2)
dev.off()

TCGA<-read.table("Riskscore.txt",header=T,sep="\t")
predict_1_year<- 1
predict_3_year<- 3
predict_5_year<- 5

ROC<-timeROC(T=TCGA$survival_time,delta=TCGA$status,
             marker=TCGA$Riskscore,cause=1,
             weighting="marginal",
             times=c(predict_1_year,predict_3_year,predict_5_year),ROC=T)

pdf("ROC.pdf")
plot(ROC,time=predict_1_year,title=F,lwd=3)
plot(ROC,time=predict_3_year,col="yellow",add=T,title=F,lwd=3)
plot(ROC,time=predict_5_year,col="blue",add=T,title=F,lwd=3)
legend("bottomright",
       c(paste("AUC of 1 year survival: ",round(ROC$AUC[1],3)),
         paste("AUC of 3 year survival: ",round(ROC$AUC[2],3)),
         paste("AUC of 5 year surviva",round(ROC$AUC[3],3))),col=c("red","yellow","blue"),lwd=3)#更改颜色
dev.off()

riskdata=read.table("Riskscore.txt",header = T,sep = "\t",row.names = 1)
riskdata=riskdata[order(riskdata$Riskscore),]  
nriskdata=riskdata[c(3:(ncol(riskdata)-2))]
nriskdata=t(nriskdata)
nriskdata=log2(nriskdata+1)
mycolor=list()
mycolor2=c("green", "red")
names(mycolor2)=c("Low", "High")
mycolor[["Riskgroup"]]=mycolor2
ann=data.frame(Riskgroup=riskdata[,ncol(riskdata)])
rownames(ann)=rownames(riskdata)


pdf("heatmap.pdf",10,8)
pheatmap(nriskdata, 
         annotation=ann,
         annotation_colors = mycolor, 
         cluster_cols = F,
         cluster_rows = F,
         show_colnames = F,
         scale="row",
         color= colorRampPalette(c("green", "black", "red"))(50),
         fontsize_col=4,
         fontsize=8,
         fontsize_row=8)
dev.off()

