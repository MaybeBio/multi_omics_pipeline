

#install.packages("survminer")
library(survival)
library(survminer)
setwd("E:\\生信\\chromatin\\13_step13")      
mydata1=read.table("Riskscore.txt", header=T, sep="\t", check.names=F)
mydata2=read.table("clinical.txt", header=T, sep="\t", check.names=F)
mydata3=merge(mydata1,mydata2,by="id")
head(mydata3)
clinical1="stage"
clinical2="III+IV"
mytitle=paste0(clinical2," ","Risk")
surdata=mydata3[mydata3[,clinical1]==clinical2,]
mydiff=survdiff(Surv(survival_time, status) ~Riskgroup,data = surdata)
myfit <- survfit(Surv(survival_time, status) ~Riskgroup, data = surdata)
p=1-pchisq(mydiff$chisq,df=1)
if(p<0.001){
  p="p<0.001"
}else{
  p=paste0("p=",sprintf("%.03f",p))
}

pdf(file=paste0("survival.",clinical1,"2","_",".pdf"), onefile = F,8,6)#修改PDF文件名字
ggsurvplot(myfit, 
           data=surdata,
           conf.int=F,
           pval=p,
           pval.size=6,
           legend.title=mytitle,
           legend.labs=c("High risk", "Low risk"),
           xlab="Time(years)",
           break.time.by = 1,
           palette=c("red", "blue"),
           risk.table=F,
          )
dev.off()