####关注微信公众号生信狂人团队
###遇到代码报错等不懂的问题可以添加微信scikuangren进行答疑
###作者邮箱：sxkrteam@shengxinkuangren.com
library(ggpubr)
library(limma)

setwd("E:\\生信\\chromatin\\20_step20")
immcheck=read.table("Immune_checkpoint_genes.txt",header = F,sep = "\t",check.names = F)
tcga=read.table("mRNA.txt",header = T,sep = "\t",check.names =F)
tcga=as.matrix(tcga)
rownames(tcga)=tcga[,1]
GeneExp=tcga[,2:ncol(tcga)]
TCGA=matrix(as.numeric(as.matrix(GeneExp)),nrow=nrow(GeneExp),dimnames=list(rownames(GeneExp),colnames(GeneExp)))
TCGA=TCGA[rowMeans(TCGA)>0,]
st<- which(substr(colnames(TCGA),14,15) == '11')
tumor=TCGA[,-st]
tumor=avereps(tumor)
tumor=as.data.frame(tumor)
nc=substr(colnames(tumor),1,12)
colnames(tumor)=nc
tumor=tumor[as.vector(immcheck[,1]),]
tumor=na.omit(tumor)
tumor=t(tumor)
tumor=cbind(id=rownames(tumor),tumor)
risk=read.table("Riskscore.txt",header = T,sep = "\t",check.names = F)
risk_mRNA=merge(risk,tumor,by="id")

for(a in colnames(risk_mRNA[,3:ncol(risk_mRNA)])){
  risk_mRNA$Risk=factor(risk_mRNA$Risk, levels=c("Low", "High"))
  mygroup=levels(factor(risk_mRNA[,"Risk"]))
  mycom=combn(mygroup, 2)
  mycomlist=list()
  for(b in 1:ncol(mycom)){mycomlist[[b]]<-mycom[,b]}
  df=data.frame(Risk=risk_mRNA$Risk,a=as.numeric(risk_mRNA[,a]))
  wilcox_test=wilcox.test(a~Risk, data=df)
  
  if(wilcox_test$p.value<0.001){
    myviolin=ggviolin(df, x="Risk", y="a", fill = "Risk", 
                      palette = c('green','red'),
                      add = "boxplot", 
                      add.params = list(fill="white"),
                      order=mygroup)+ 
      stat_compare_means(comparisons = mycomlist,label="p.signif")
    pdf(file=paste0(a, ".pdf"))
    print(myviolin)
    dev.off()
  }
}

