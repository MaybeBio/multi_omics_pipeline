

library(survival)
setwd("E:\\桌面\\chromatin\\6.1mRNA生存分析")

inputmiRNA=read.table("newinput.txt",head=T,sep ="\t",check.names = F)
result=data.frame()

for(a in colnames(inputmiRNA[,4:ncol(inputmiRNA)])){
  exp<-factor(ifelse(inputmiRNA[,a]>median(inputmiRNA[,a]),"high","low"))
  kms<-survfit(Surv(survival_time,status)~exp,data=inputmiRNA)
  kmdffexp=survdiff(Surv(survival_time,status)~exp,data=inputmiRNA)
  pValue=round(1-pchisq(kmdffexp$chisq,df=1),5)
  myname=unlist(strsplit(a,"\\|"))[1]
  pdffile=paste(myname,".pdf")
  if (pValue < 0.05){
    if(pValue<0.001){
      pValue="p<0.001"
    }else{
      pValue=paste0("p=",sprintf("%.03f",pValue))
    }
    result=rbind(result,cbind(gene=a,pvalue=pValue))
    pdf(file = pdffile)
    plot(kms,lty=1.8,col=rainbow(2), mark.time=T,
         xlab="Survival time in years",ylab="Survival probabilities",
         main=paste(myname,"(", pValue ,")",sep=""))
    legend("bottomleft",c("High expression","Low expression"),lty=1.8,col=rainbow(2))
    dev.off()
  }
}
  
write.table(result,"result.txt",sep="\t",row.names=F,quote=F)
