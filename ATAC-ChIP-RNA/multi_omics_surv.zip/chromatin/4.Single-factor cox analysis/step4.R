library(survival)
setwd("E:\\生信\\chromatin\\4_step4")
dt1=read.table("diffgeneEXP.txt",header = T,sep = "\t",check.names = F)
st<- which(substr(colnames(dt1),14,15) == '11')
tumor=dt1[,-st]
nc=substr(colnames(tumor),1,12)
colnames(tumor)=nc
tumor=t(tumor)
write.table(tumor,"tumor.txt",sep = "\t",quote = F,col.names = F)
dt4=read.table("tumor.txt",header = T,sep = "\t",check.names =F)
clidata=read.table("time.txt",header = T,sep = "\t",check.names =F)
cliexp=merge(clidata,dt4,by="id")
write.table(cliexp,"timeexp.txt",sep = "\t",quote = F,row.names = F)

inputfile="timeexp.txt"
data1=read.table(inputfile,header = T,sep = "\t",check.names =F,row.names = 1)
data1$survival_time=data1$survival_time/365

coxf<-function(x){
  fmla1 <- as.formula(Surv(survival_time,status)~data1[,x])
  mycox <- coxph(fmla1,data=data1)
}

newdf=data.frame()
for(a in colnames(data1[,3:ncol(data1)])){
  mycox=coxf(a)
  coxResult = summary(mycox)
  newdf=rbind(newdf,
              cbind(id=a,
                    HR=coxResult$conf.int[,"exp(coef)"],
                    HR_95L=coxResult$conf.int[,"lower .95"],
                    HR_95U=coxResult$conf.int[,"upper .95"],
                    P=coxResult$coefficients[,"Pr(>|z|)"]
              ))
  
}
newdf=newdf[(newdf$P<0.05),]
write.table(newdf,"result.txt",sep="\t",row.names=F,quote=F)

###################forest################

HRdf1<- read.table("top20.txt", header=T, sep="\t", check.names=F, row.names=1)
idname <- rownames(HRdf1)
HR=sprintf("%.4f",HRdf1[,"HR"])
HR_95L=sprintf("%.4f",HRdf1[,"HR_95L"])
HR_95U=sprintf("%.4f",HRdf1[,"HR_95U"])
P=HRdf1[,"P"]
P=ifelse(P<0.001, "<0.001", sprintf("%.4f", P))

pdf("forest.pdf")
snum <- nrow(HRdf1)
snum2 <- snum+1
layout(matrix(c(1,2),nc=2),width=c(3,2.5))
par(mar=c(4,2.5,2,1))
plot(1,xlim= c(0,3),ylim=c(1,snum2),type="n",axes=F,xlab="",ylab="")
text(0,snum:1,idname,adj=0,cex=0.8)
text(1.5-0.5*0.2,snum:1,P,adj=1,cex=0.8);text(1.5-0.5*0.2,snum+1,'pvalue',cex=0.8,font=2,adj=1)
text(3.1,snum:1, paste0(HR,"(",HR_95L,"-",HR_95U,")"),adj=1,cex=0.8);text(3.1,snum+1,'Hazard ratio',cex=0.8,font=2,adj=1)
par(mar=c(4,1,2,1),mgp=c(2,0.5,0))
xlim = c(0,max(as.numeric(HR_95L),as.numeric(HR_95U)))
plot(1,xlim=c(0,3),ylim=c(1,snum2),type="n",axes=F,ylab="",xaxs="i",xlab="Hazard ratio")
arrows(as.numeric(HR_95L),snum:1,as.numeric(HR_95U),
       snum:1,angle=90,code=3,length=0.05,col="skyblue",lwd=2.5)
abline(v=1,col="black",lty=2,lwd=2)
points(as.numeric(HR), snum:1, pch = 15, 
       col = ifelse(as.numeric(HR) > 1, "red", "green")
       , cex=1.5)
axis(1)
dev.off()


