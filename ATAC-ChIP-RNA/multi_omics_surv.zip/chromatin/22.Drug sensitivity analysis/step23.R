if (!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")
BiocManager::install(c("car", "ridge", "preprocessCore", "genefilter", "sva"))

install.packages("ggpubr")


####关注微信公众号生信狂人团队
###遇到代码报错等不懂的问题可以添加微信scikuangren进行答疑
###作者邮箱：sxkrteam@shengxinkuangren.com
library(limma)
library(ggpubr)
library(pRRophetic)
library(ggplot2)
set.seed(666)


setwd("C:\\Users\\zxz96\\Desktop\\chromatin\\22.药物敏感性分析")  
mydrugs=c("A.443654", "A.770041", "ABT.263", "ABT.888", "AG.014699", "AICAR", "AKT.inhibitor.VIII", "AMG.706", "AP.24534", "AS601245", "ATRA", "AUY922", "Axitinib", "AZ628", "AZD.0530", "AZD.2281", "AZD6244", "AZD6482", "AZD7762", "AZD8055", "BAY.61.3606", "Bexarotene", "BI.2536", "BIBW2992", "Bicalutamide", "BI.D1870", "BIRB.0796", "Bleomycin", "BMS.509744", "BMS.536924", "BMS.708163", "BMS.754807", "Bortezomib", "Bosutinib", "Bryostatin.1", "BX.795", "Camptothecin", "CCT007093", "CCT018159", "CEP.701", "CGP.082996", "CGP.60474", "CHIR.99021", "CI.1040", "Cisplatin", "CMK", "Cyclopamine", "Cytarabine", "Dasatinib", "DMOG", "Docetaxel", "Doxorubicin", "EHT.1864", "Elesclomol", "Embelin", "Epothilone.B", "Erlotinib", "Etoposide", "FH535", "FTI.277", "GDC.0449", "GDC0941", "Gefitinib", "Gemcitabine", "GNF.2", "GSK269962A", "GSK.650394", "GW.441756", "GW843682X", "Imatinib", "IPA.3", "JNJ.26854165", "JNK.9L", "JNK.Inhibitor.VIII", "JW.7.52.1", "KIN001.135", "KU.55933", "Lapatinib", "Lenalidomide", "LFM.A13", "Metformin", "Methotrexate", "MG.132", "Midostaurin", "Mitomycin.C", "MK.2206", "MS.275", "Nilotinib", "NSC.87877", "NU.7441", "Nutlin.3a", "NVP.BEZ235", "NVP.TAE684", "Obatoclax.Mesylate", "OSI.906", "PAC.1", "Paclitaxel", "Parthenolide", "Pazopanib", "PD.0325901", "PD.0332991", "PD.173074", "PF.02341066", "PF.4708671", "PF.562271", "PHA.665752", "PLX4720", "Pyrimethamine", "QS11", "Rapamycin", "RDEA119", "RO.3306", "Roscovitine", "Salubrinal", "SB.216763", "SB590885", "Shikonin", "SL.0101.1", "Sorafenib", "S.Trityl.L.cysteine", "Sunitinib", "Temsirolimus", "Thapsigargin", "Tipifarnib", "TW.37", "Vinblastine", "Vinorelbine", "Vorinostat", "VX.680", "VX.702", "WH.4.023", "WO2009093972", "WZ.1.84", "X17.AAG", "X681640", "XMD8.85", "Z.LLNle.CHO", "ZM.447439")
#mydrugs=c("Camptothecin", "Mitomycin C", "Thapsigargin", "Gemcitabine", "Pazopanib", "Docetaxel", "Sunitinib", "Cisplatin", "Vinblastine")
#"Camptothecin", "Mitomycin C", "Thapsigargin", "Gemcitabine", "Pazopanib", "Docetaxel", "Sunitinib", "Cisplatin", "Vinblastine"
#"Cyclopamine", "Cytarabine", "Dasatinib", "DMOG", "Docetaxel"
risk=read.table("Riskscore.txt",header = T,sep = "\t",check.names = F,row.names = 1)
mRNA=read.table("tumor.txt",header = T,sep = "\t",check.names =F)
mRNA=as.matrix(mRNA)
rownames(mRNA)=mRNA[,1]
Geneexp=mRNA[,2:ncol(mRNA)]
newdf=matrix(as.numeric(as.matrix(Geneexp)),nrow=nrow(Geneexp),dimnames=list(rownames(Geneexp),colnames(Geneexp)))
newdf=avereps(newdf)
newdf=t(newdf)

####关注微信公众号生信狂人团队
###遇到代码报错等不懂的问题可以添加微信scikuangren进行答疑
###作者邮箱：sxkrteam@shengxinkuangren.com
for (drugi in mydrugs){
drug_sen=pRRopheticPredict(newdf, drugi, selection=1)
drug_sen=drug_sen[drug_sen!="NaN"]
coid=intersect(row.names(risk), names(drug_sen))
risk=risk[coid, "Risk",drop=F]
drug_sen=drug_sen[coid]
drugrisk=cbind(risk, drug_sen)
risk$Risk=factor(risk$Risk, levels=c("Low", "High"))
mygroup=levels(factor(risk[,"Risk"]))
mycom=combn(mygroup, 2)
mycomlist=list()
for(b in 1:ncol(mycom)){mycomlist[[b]]<-mycom[,b]}
wilcox_test=wilcox.test(drug_sen~Risk, drugrisk)
if (wilcox_test$p.value<0.05){
myboxplot=ggboxplot(drugrisk, x="Risk", y="drug_sen", fill = "Risk", palette = c('green','red'),ylab=paste0(drugi, " senstivity (IC50)"),
                    add.params = list(fill="white"),
                    order=mygroup)+ 
    stat_compare_means(comparisons = mycomlist)
  pdf(file=paste0(drugi, ".pdf"))
  print(myboxplot)
  dev.off()
}
}

####关注微信公众号生信狂人团队
###遇到代码报错等不懂的问题可以添加微信scikuangren进行答疑
###作者邮箱：sxkrteam@shengxinkuangren.com
